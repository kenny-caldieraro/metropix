Found a town in 1950 and grow it into the city of tomorrow.

Metropix is a pixel-art city-building game inspired by the great classics of the genre, with the depth of modern games. Lay out streets, zone residential, commercial, industrial and office areas, and watch your city come to life.

MANAGE EVERY DETAIL
• Power, drinking water, sewage and waste: every network matters
• Streets, one-way roads, avenues, highways, bridges and tunnels
• Buses, trams, metro, passenger and freight trains
• Police, fire, health, education, daycare, retirement homes, cemeteries…

A LIVING, MODERN CITY
• Districts with their own taxes, rules and specializations: tourism, farming, forestry, high tech
• Air, water, soil and noise pollution, carbon footprint, urban forests and low-emission zones
• Neighboring cities: sell power, buy water, trade waste
• Landmarks, tourism and major facilities

LIVE THROUGH THE ERAS
• From post-war towns to 70s concrete, glass and steel, and the sustainable city of tomorrow
• Every building keeps the style of its era; older ones are gradually renovated
• Start in 1950, 1975, 2000 or 2025

MAYORAL CHOICES
• Events to decide: strikes, festivals, a chemical plant, heatwaves…
• Detailed budget, loans and city policies
• Advisors who flag problems and opportunities
• Disasters: fires, earthquakes, tornadoes… if you turn them on

CAREFUL PIXEL ART
• Day and night cycle, seasons, rain and snow, cars, trains, boats and planes
• Buses, garbage trucks, fire engines and ambulances that leave from their buildings
• Photo mode, 20 achievements, guided tutorial, 3 save slots, sandbox mode
• Play in portrait or landscape, in English or French

No ads, no in-app purchases, no connection required.