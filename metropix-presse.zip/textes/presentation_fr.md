# Metropix — fiche App Store (français)

**Nom** : Metropix
**Sous-titre** (30 car. max) : Bâtissez et gérez votre ville
**Catégorie** : Jeux › Simulation (secondaire : Stratégie)
**Prix** : gratuit, sans publicité ni achat intégré
**Âge** : 4+ (catastrophes naturelles non réalistes, pas de violence)

## Texte promotionnel (170 car. max)
Quatre époques d'architecture, des décisions de maire, 20 succès : fondez votre ville en 1950 et menez-la jusqu'à la ville de demain.

## Description
Fondez une ville en 1950 et faites-la grandir jusqu'à la ville de demain.

Metropix est un jeu de gestion de ville en pixel art, inspiré des grands classiques du genre, avec la profondeur des jeux modernes. Tracez les rues, posez les zones résidentielles, commerciales, industrielles et de bureaux, et regardez votre ville prendre vie.

GÉREZ CHAQUE DÉTAIL
• Électricité, eau potable, égouts et déchets : chaque réseau compte
• Rues, sens uniques, avenues, voies rapides, ponts et tunnels
• Bus, tram, métro et trains de voyageurs ou de fret
• Police, pompiers, santé, éducation, crèches, maisons de retraite, cimetières…

UNE VILLE VIVANTE ET MODERNE
• Quartiers avec leurs propres impôts, règles et spécialisations : tourisme, agriculture, sylviculture, haute technologie
• Pollution de l'air, de l'eau, des sols et du bruit, bilan carbone, forêts urbaines et zones à faibles émissions
• Villes voisines : vendez votre électricité, achetez de l'eau, échangez vos déchets
• Monuments, tourisme et grands équipements

TRAVERSEZ LES ÉPOQUES
• De l'après-guerre au béton des années 70, du verre et de l'acier à la ville durable de demain
• Chaque bâtiment garde le style de son époque, les anciens se rénovent peu à peu
• Commencez en 1950, 1975, 2000 ou 2025

DES CHOIX DE MAIRE
• Événements à trancher : grève, festival, usine chimique, canicule…
• Budget détaillé, emprunts et dix politiques municipales
• Conseillers qui signalent les problèmes et les opportunités
• Catastrophes : incendies, séismes, tornades… si vous les activez

UN PIXEL ART SOIGNÉ
• Cycle jour et nuit, saisons, pluie et neige, voitures, trains, bateaux et avions
• Bus, bennes, pompiers et ambulances qui partent de leurs bâtiments
• Mode photo, 20 succès, tutoriel guidé, 3 emplacements de sauvegarde, bac à sable
• Jouable en portrait comme en paysage, en français et en anglais

Sans publicité, sans achat intégré, sans connexion requise.

## Mots-clés (100 car. max, séparés par des virgules)
ville,gestion,construction,simulation,maire,urbanisme,pixel,city,builder,zones,rétro,stratégie,métropole

## Notes de version (1.0)
Première version de Metropix. Bonne construction !

## Adresses
- Politique de confidentialité : https://kenny-caldieraro.github.io/metropix/confidentialite.html
- Assistance : https://kenny-caldieraro.github.io/metropix/
- Conditions générales d'utilisation : https://kenny-caldieraro.github.io/metropix/cgu.html
